## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
  collapse  = TRUE,
  comment   = "#>",
  fig.width = 7,
  fig.height = 5
)

## ----install, eval = FALSE----------------------------------------------------
# # From a local source directory:
# devtools::install("path/to/MBbioeq")
# 
# # Or once submitted to CRAN:
# install.packages("MBbioeq")

## ----load---------------------------------------------------------------------
library(MBbioeq)

## ----data-path----------------------------------------------------------------
data_path <- system.file("extdata", "dataset_1.txt", package = "MBbioeq")

## ----prep, eval = FALSE-------------------------------------------------------
# raw <- read.table(data_path, header = TRUE)
# tab <- prep_parallel_TR(raw)
# head(tab)
# #>   Id Dose Time Concentration Treat
# #> 2  1    4  0.5         2.217     0
# #> 3  1    4  1.0         3.840     0
# #> ...

## ----spaghetti, eval = FALSE--------------------------------------------------
# plot_spaghetti(data_path)

## ----tost-run, eval = FALSE---------------------------------------------------
# psi0      <- c(ka = 1.5, V = 0.5, CL = 0.04)
# omega_init <- c(0.2, 0.3, 0.2)   # diagonal random effects
# 
# res_tost <- run_MBTost(
#   data_path   = data_path,
#   model       = "1cpt",
#   psi0        = psi0,
#   omega_init  = omega_init,
#   error_model = "combined",
#   error_init  = c(0.1, 0.2)
# )

## ----tost-plot, eval = FALSE--------------------------------------------------
# plot_tost(res_tost)

## ----tost-plot-show, eval = FALSE---------------------------------------------
# # Display only the Gallant-corrected CIs:
# plot_tost(res_tost, method = "gallant")

## ----bot-run, eval = FALSE----------------------------------------------------
# res_bot <- run_MBbot(
#   data_path   = data_path,
#   model       = "1cpt",
#   psi0        = psi0,
#   omega_init  = omega_init,
#   error_model = "combined",
#   error_init  = c(0.1, 0.2)
# )

## ----bot-plot, eval = FALSE---------------------------------------------------
# plot_bot(res_bot)

## ----tlag-example, eval = FALSE-----------------------------------------------
# res_tlag <- run_MBTost(
#   data_path   = data_path,
#   model       = "1cpt_tlag",
#   psi0        = c(ka = 1.5, V = 0.5, CL = 0.04, tlag = 0.5),
#   omega_init  = c(0.2, 0.3, 0.2, 0.1),
#   error_model = "combined"
# )
# plot_tost(res_tlag)

## ----cov-example, eval = FALSE------------------------------------------------
# # Full covariance matrix (all off-diagonals estimated)
# run_MBTost(data_path, model = "1cpt", covariance_structure = "full")
# 
# # Custom: only CL-V covariance
# omega_block <- matrix(c(1, 0, 0,
#                         0, 1, 1,
#                         0, 1, 1), nrow = 3)
# run_MBTost(data_path, model = "1cpt", covariance_structure = omega_block)

## ----delta-example, eval = FALSE----------------------------------------------
# run_MBTost(data_path, model = "1cpt", delta = log(1.111))  # 90–111 % range

## ----alpha-example, eval = FALSE----------------------------------------------
# run_MBTost(data_path, model = "1cpt", alpha = 0.10)  # 80 % CI (more liberal)

## ----save-plot, eval = FALSE--------------------------------------------------
# pdf("tost_result.pdf", width = 8, height = 5)
# plot_tost(res_tost)
# dev.off()
# 
# png("spaghetti.png", width = 800, height = 500)
# plot_spaghetti(data_path)
# dev.off()

## ----session------------------------------------------------------------------
sessionInfo()

